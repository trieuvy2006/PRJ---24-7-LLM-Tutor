// B�i n?p m�n CSD201 - Data Structures and Algorithms
// Sinh vi�n: Luong Tri?u V? (QE200035)
// L?n n?p 2 - �� kh?c ph?c di?u ki?n bi�n theo g�p � c?a AI Tutor
public class DoublyLinkedList {
    class Node {
        int data;
        Node prev, next;
        Node(int d) { data = d; }
    }
    private Node head = null, tail = null;

    public void addLast(int val) {
        Node newNode = new Node(val);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void removeFirst() {
        if (head == null) return;
        if (head == tail) {
            head = tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
    }

    public void removeLast() {
        if (tail == null) return;
        if (head == tail) {
            head = tail = null;
        } else {
            tail = tail.prev;
            tail.next = null;
        }
    }

    public void display() {
        Node curr = head;
        while (curr != null) {
            System.out.print(curr.data + " <-> ");
            curr = curr.next;
        }
        System.out.println("null");
    }
}
